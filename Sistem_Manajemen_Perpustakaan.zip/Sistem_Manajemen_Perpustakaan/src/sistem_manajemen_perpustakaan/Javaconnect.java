/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistem_manajemen_perpustakaan;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Edward
 */
public class Javaconnect
{
  public static Connection ConnectDB()
   {
       try
       {
            String url = "jdbc:mysql://localhost:3306/manajemenperpustakaan";
            String uname = "root";
            String pass = "";
      
            Class.forName("com.mysql.jdbc.Driver");

            Connection conn = DriverManager.getConnection(url, uname, pass);

            return conn;
     }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
            return null;
        }
    }
}

